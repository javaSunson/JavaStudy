package com.oaec.dao.impl;

import java.util.List;

import com.oaec.dao.UserDao;
import com.oaec.db.DBUtil;
import com.oaec.entity.User;
import com.oaec.view.MainViews;

public class UserDaoImpl implements UserDao {
	List<User> u_list = DBUtil.getUserList();
	@Override
	public List<User> selectAll() {
		return u_list;
	}
	@Override
	public boolean isExist(String userName) {
		for (User user : u_list) {
			if (user.getUserName().equals(userName)) {
				return true;//�û�����
			}
		}
		return false;//�û�������
	}
	@Override
	public User login(String userName, String password) {
		for (User user : u_list) {
			if (user.getUserName().equals(userName)&&user.getPassword().equals(password)) {
				return user;//�û���¼�ɹ�
			}
		}
		return null;
	}
	//��δ����Ǹղų�����λ��
	@Override
	public void register() {
		// TODO Auto-generated method stub
		MainViews.register();
		
	}
	@Override
	public Boolean DeleteUser(String name) {
		// TODO Auto-generated method stub
		
		return null;
	}
}
