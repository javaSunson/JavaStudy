package com.oaec.dao.impl;

import java.util.List;

import com.oaec.dao.CarDao;
import com.oaec.db.DBUtil;
import com.oaec.entity.Car;
import com.oaec.entity.User;

public class CarDaoImpl implements CarDao {
	private RecordDaoImpl rdi = new RecordDaoImpl();
	private List<Car> c_list = DBUtil.getCarList();
	@Override
	public List<Car> selectAll() {
		// TODO Auto-generated method stub
		return c_list;
	}

	@Override
	public int rentById(User u,int id) {
		for (Car car : c_list) {
			if (car.getId()==id) {
				if (car.isRent()) {
					//�ڼ�¼�����ϼ���һ����¼
					boolean addRecord = rdi.addRecord(u, id);
					if (addRecord) {
						car.setRent(false);
						car.setCount(car.getCount()+1);
						return 1;//�������⣬�����ɹ�
					}else{
						return -1;
					}
				}else{
					return 2;//����������
				}
			}
		}
		return 3;//����������
	}

	@Override
	public boolean addCar(Car c) {
		return c_list.add(c);
	}

	@Override
	public boolean deleteCar(int id) {
		for (Car car : c_list) {
			if (car.getId()==id) {
				if (car.isRent()) {
					boolean remove = c_list.remove(car);
					return remove;
				}
			}
		}
		return false;
	}
}
