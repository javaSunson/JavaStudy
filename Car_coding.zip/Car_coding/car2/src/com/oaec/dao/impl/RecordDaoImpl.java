package com.oaec.dao.impl;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.oaec.dao.RecordDao;
import com.oaec.db.DBUtil;
import com.oaec.entity.Car;
import com.oaec.entity.Record;
import com.oaec.entity.User;

public class RecordDaoImpl implements RecordDao{
	private List<Record> r_list = DBUtil.getRecordList();
	private List<Car> c_list = DBUtil.getCarList();
	@Override
	public List<Record> selectAll() {
		// TODO Auto-generated method stub
		return r_list;
	}

	@Override
	public List<Record> selectByName(String uName) {
		List<Record> list = new ArrayList<Record>();
		for (Record record : r_list) {
			if (record.getUserName().equals(uName)) {
				list.add(record);
			}
		}
		return list;
	}
//�����Ѿ�д�˹黹ʱ�䡣������
	@Override
	public boolean addRecord(User u,int carId) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
		Date date = new Date();
		return 	r_list.add(new Record(DBUtil.getRecordId(),carId,u.getUserName(),sdf.format(date),null,false));
	}

	@Override
	public boolean updateRecord(int recordId) {
		for (Record record : r_list) {
			if (record.getId()==recordId) {
				int carId = record.getCarId();
				boolean backById = backById(carId);
				if (backById) {
					record.setBack(true);
					record.setBackDate(new SimpleDateFormat("yyyy-MM-dd hh:mm:ss").format(new Date()));
					return true;
				}
			}
		}
		return false;
	}
	private boolean backById(int id) {
		for (Car car : c_list) {
			if (car.getId()==id) {
				car.setRent(true);
				return true;
			}
		}
		return false;
	}
}
