package com.oaec.entity;

public class Record {
	private int id;// ��¼ID
	private int carId;// �������ID
	private String userName;// �賵������
	private String rentDate;// �賵ʱ��
	private String backDate;// �黹ʱ��
	private boolean isBack;// �Ƿ��Ѿ��黹

	public Record() {
	}

	public Record(int id, int carId, String userName, String rentDate, String backDate, boolean isBack) {
		super();
		this.id = id;
		this.carId = carId;
		this.userName = userName;
		this.rentDate = rentDate;
		this.backDate = backDate;
		this.isBack = isBack;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getCarId() {
		return carId;
	}

	public void setCarId(int carId) {
		this.carId = carId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getRentDate() {
		return rentDate;
	}

	public void setRentDate(String rentDate) {
		this.rentDate = rentDate;
	}

	public String getBackDate() {
		return backDate;
	}

	public void setBackDate(String backDate) {
		this.backDate = backDate;
	}

	public boolean isBack() {
		return isBack;
	}

	public void setBack(boolean isBack) {
		this.isBack = isBack;
	}

	@Override
	public String toString() {
		String temp;
		if(isBack==true) {
			temp="�ѻ�";
		}else {
			temp="δ��";
		}
		return "ID:" + id + "����ID��" + carId + "�Ñ�����" + userName + "�����Ϣ��" + rentDate + "�黹���ڣ�"
				+ backDate + "�Ƿ��ѻ���" + temp;
	}

}
