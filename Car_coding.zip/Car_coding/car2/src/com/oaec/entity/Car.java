package com.oaec.entity;

public class Car {
	private int id;//����ID
	private String brand;//����Ʒ���ͺ�
	private double money;//���
	private int count;//�������
	private boolean isRent;//�Ƿ����
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getBrand() {
		return brand;
	}
	public void setBrand(String brand) {
		this.brand = brand;
	}
	public double getMoney() {
		return money;
	}
	public void setMoney(double money) {
		this.money = money;
	}
	public boolean isRent() {
		return isRent;
	}
	public void setRent(boolean isRent) {
		this.isRent = isRent;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	
	public Car(int id, String brand, double money, int count, boolean isRent) {
		super();
		this.id = id;
		this.brand = brand;
		this.money = money;
		this.count = count;
		this.isRent = isRent;
	}
	public Car() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "ID:" + id + "\t������:" + brand + "\t����" + money + "\t\t������:" + count + "\t״̬:" + isRent;
	}
	
}
