package com.oaec.db;

import java.util.ArrayList;
import java.util.List;

import com.oaec.entity.Car;
import com.oaec.entity.Record;
import com.oaec.entity.User;
/***
 * 2017��10��25�� ������id
 * @author sun
 *
 */
public class DBUtil {
	private static List<User> u_list = new ArrayList<User>();
	private static List<Car> c_list = new ArrayList<Car>();
	private static List<Record> r_list = new ArrayList<Record>();
	static{
		User u = new User(1,"gary", "123","��","110", true);
		User u1 = new User(2,"anan", "123","Ů","120", false);
		u_list.add(u);
		u_list.add(u1);
		Car c = new Car(1,"A", 123.2,0,true);
		Car c1 = new Car(2,"B", 223.2,0,true);
		Car c2 = new Car(3,"A", 423.2,0,false);
		Car c3 = new Car(4,"C", 523.2,0,true);
		Car c4 = new Car(5,"D", 623.2,0, true);
		c_list.add(c);	
		c_list.add(c1);
		c_list.add(c2);
		c_list.add(c3);
		c_list.add(c4);
		
	}
	//��ü��϶���
	public static List<User> getUserList(){
		return u_list;
	}
	public static List<Car> getCarList(){
		return c_list;
	}
	public static List<Record> getRecordList(){
		return r_list;
	}
	//��ȡ��һ��id��
	public static int getUserId(){
		if (u_list.size()>0) {
			return u_list.get(u_list.size()-1).getId()+1;
//			return u_list.size()-1+1;
		}else{
			return 1;
		}
	}
	public static int getCarId(){
		if (c_list.size()>0) {
			return c_list.get(c_list.size()-1).getId()+1;
		}else{
			return 1;
		}
	}
	public static int getRecordId(){
		if (r_list.size()>0) {
			return r_list.get(r_list.size()-1).getId()+1;
//			return r_list.size()-1+1;
		}else{
			return 1;
		}
	}
}	
