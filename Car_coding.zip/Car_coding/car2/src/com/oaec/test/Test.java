package com.oaec.test;

import com.oaec.view.MainViews;

public class Test {
	public static void main(String[] args) {
		MainViews.begin();
	}
}
